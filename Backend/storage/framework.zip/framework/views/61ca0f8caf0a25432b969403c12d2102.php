<div class="flex gap-2">
    <img class="w-30" src="<?php echo e(asset('Mobile DocCare Group 4.svg')); ?>" alt="Logo">
</div>
<?php /**PATH C:\Users\vinun\Desktop\Term 7\Capstone-Project-II\Backend\resources\views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>